# Event-Management-System-Team-3

Under supervision of Sandip Sir.

Infosys Springboard Python Internship.
